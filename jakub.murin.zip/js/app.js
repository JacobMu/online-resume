//no idea what this is 
let admin, 
    name; 
    
name = 'John';

admin=name;
console.log(admin);

